import { create } from 'zustand';
import { ProjectState } from '../types';

const mockProjects = [
  {
    id: '1',
    name: 'Image Classification Model',
    status: 'deployed',
    deployedUrl: 'https://google.com',
    previewUrl: 'https://google.com',
    createdAt: '2024-03-15',
    userId: 'dev-user',
    description: 'ResNet50 model for classifying images into 1000 categories',
    modelType: 'Computer Vision',
    framework: 'PyTorch'
  },
  {
    id: '2',
    name: 'Text Generation GPT',
    status: 'processing',
    createdAt: '2024-03-14',
    userId: 'dev-user',
    description: 'Fine-tuned GPT model for generating technical documentation',
    modelType: 'NLP',
    framework: 'Transformers'
  },
  {
    id: '3',
    name: 'Recommendation Engine',
    status: 'failed',
    createdAt: '2024-03-13',
    userId: 'dev-user',
    description: 'Collaborative filtering model for product recommendations',
    modelType: 'RecSys',
    framework: 'TensorFlow'
  }
] as const;

export const useProjectStore = create<ProjectState>((set) => ({
  projects: mockProjects,
  selectedProject: null,
  addProject: (project) => 
    set((state) => ({ projects: [...state.projects, project] })),
  updateProject: (id, updates) =>
    set((state) => ({
      projects: state.projects.map((p) =>
        p.id === id ? { ...p, ...updates } : p
      ),
    })),
  setSelectedProject: (project) =>
    set({ selectedProject: project })
}));