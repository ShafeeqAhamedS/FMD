import { create } from 'zustand';
import { AuthState } from '../types';

// Mock user for development
const mockUser = {
  id: 'dev-user',
  email: 'dev@example.com',
  name: 'John Doe',
  avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
  role: 'Senior ML Engineer',
  company: 'TechCorp',
  location: 'San Francisco, CA'
};

export const useAuthStore = create<AuthState>((set) => ({
  user: mockUser,
  login: async (email: string, password: string) => {
    set({ user: mockUser });
  },
  logout: () => {
    set({ user: mockUser });
  },
  updateProfile: (updates) => {
    set((state) => ({
      user: state.user ? { ...state.user, ...updates } : null
    }));
  }
}));