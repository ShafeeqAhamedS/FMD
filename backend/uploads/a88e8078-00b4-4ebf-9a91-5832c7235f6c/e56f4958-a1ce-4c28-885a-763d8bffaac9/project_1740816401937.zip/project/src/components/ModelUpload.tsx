import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload } from 'lucide-react';

export default function ModelUpload() {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    // Mock API call to upload file
    const formData = new FormData();
    formData.append('file', file);

    fetch('http://api.example.com/upload', {
      method: 'POST',
      body: formData,
    });
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/zip': ['.zip'],
    },
    maxFiles: 1,
  });

  return (
    <div
      {...getRootProps()}
      className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors
        ${
          isDragActive
            ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
            : 'border-gray-300 dark:border-gray-700 hover:border-gray-400 dark:hover:border-gray-600'
        }`}
    >
      <input {...getInputProps()} />
      <Upload className="mx-auto h-12 w-12 text-gray-400" />
      <p className="mt-4 text-sm text-gray-600 dark:text-gray-400">
        Drag & drop your ML model ZIP file here, or click to select
      </p>
      <p className="mt-2 text-xs text-gray-500 dark:text-gray-500">
        Must include: requirements.txt, dataset, .ipynb file, and model weights
      </p>
    </div>
  );
}