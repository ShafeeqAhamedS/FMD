export interface User {
  id: string;
  email: string;
  name?: string;
  avatar?: string;
  role?: string;
  company?: string;
  location?: string;
}

export interface Project {
  id: string;
  name: string;
  status: 'uploading' | 'processing' | 'deployed' | 'failed';
  deployedUrl?: string;
  previewUrl?: string;
  createdAt: string;
  userId: string;
  description?: string;
  modelType?: string;
  framework?: string;
}

export interface AuthState {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
}

export interface ProjectState {
  projects: Project[];
  addProject: (project: Project) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  selectedProject: Project | null;
  setSelectedProject: (project: Project | null) => void;
}