import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileUpload } from '../components/FileUpload';
import { useProjectStore } from '../store/projects';
import { ArrowRight } from 'lucide-react';

const frameworks = [
  { id: 'pytorch', name: 'PyTorch' },
  { id: 'tensorflow', name: 'TensorFlow' },
  { id: 'sklearn', name: 'scikit-learn' },
  { id: 'transformers', name: 'Hugging Face Transformers' },
];

const modelTypes = [
  { id: 'cv', name: 'Computer Vision' },
  { id: 'nlp', name: 'Natural Language Processing' },
  { id: 'tabular', name: 'Tabular Data' },
  { id: 'recsys', name: 'Recommendation Systems' },
  { id: 'rl', name: 'Reinforcement Learning' },
];

export default function Deploy() {
  const navigate = useNavigate();
  const addProject = useProjectStore((state) => state.addProject);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    framework: '',
    modelType: '',
    files: {
      notebook: null as File | null,
      requirements: null as File | null,
      model: null as File | null,
      dataset: null as File | null,
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real app, we would upload files and create project here
    const newProject = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.name,
      description: formData.description,
      status: 'uploading' as const,
      framework: frameworks.find(f => f.id === formData.framework)?.name || '',
      modelType: modelTypes.find(t => t.id === formData.modelType)?.name || '',
      createdAt: new Date().toISOString(),
      userId: 'dev-user',
    };

    addProject(newProject);
    navigate('/dashboard');
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">Deploy New Model</h1>

      <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
        <div className="p-6">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              {[1, 2].map((number) => (
                <div
                  key={number}
                  className={`flex items-center ${
                    number === 2 ? 'flex-row-reverse' : ''
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      step >= number
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-200 dark:bg-gray-700 text-gray-500'
                    }`}
                  >
                    {number}
                  </div>
                  <div
                    className={`mx-4 text-sm font-medium ${
                      step >= number
                        ? 'text-gray-900 dark:text-white'
                        : 'text-gray-500'
                    }`}
                  >
                    {number === 1 ? 'Project Details' : 'Upload Files'}
                  </div>
                </div>
              ))}
              <div
                className={`h-1 flex-1 mx-4 ${
                  step > 1
                    ? 'bg-blue-600'
                    : 'bg-gray-200 dark:bg-gray-700'
                }`}
              />
            </div>
          </div>

          <form onSubmit={handleSubmit}>
            {step === 1 ? (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Project Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white sm:text-sm"
                    placeholder="My Awesome ML Model"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Description
                  </label>
                  <textarea
                    required
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    rows={3}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white sm:text-sm"
                    placeholder="Brief description of your model and its purpose"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Framework
                  </label>
                  <select
                    required
                    value={formData.framework}
                    onChange={(e) =>
                      setFormData({ ...formData, framework: e.target.value })
                    }
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white sm:text-sm"
                  >
                    <option value="">Select a framework</option>
                    {frameworks.map((framework) => (
                      <option key={framework.id} value={framework.id}>
                        {framework.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Model Type
                  </label>
                  <select
                    required
                    value={formData.modelType}
                    onChange={(e) =>
                      setFormData({ ...formData, modelType: e.target.value })
                    }
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white sm:text-sm"
                  >
                    <option value="">Select a model type</option>
                    {modelTypes.map((type) => (
                      <option key={type.id} value={type.id}>
                        {type.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <FileUpload
                  label="Jupyter Notebook (.ipynb)"
                  accept=".ipynb"
                  file={formData.files.notebook}
                  onChange={(file) =>
                    setFormData({
                      ...formData,
                      files: { ...formData.files, notebook: file },
                    })
                  }
                  description="Your model training notebook"
                />

                <FileUpload
                  label="Requirements (requirements.txt)"
                  accept=".txt"
                  file={formData.files.requirements}
                  onChange={(file) =>
                    setFormData({
                      ...formData,
                      files: { ...formData.files, requirements: file },
                    })
                  }
                  description="Python package dependencies"
                />

                <FileUpload
                  label="Model Weights"
                  accept=".pt,.pth,.h5,.pkl,.bin"
                  file={formData.files.model}
                  onChange={(file) =>
                    setFormData({
                      ...formData,
                      files: { ...formData.files, model: file },
                    })
                  }
                  description="Trained model weights file"
                />

                <FileUpload
                  label="Dataset"
                  accept=".csv,.json,.zip"
                  file={formData.files.dataset}
                  onChange={(file) =>
                    setFormData({
                      ...formData,
                      files: { ...formData.files, dataset: file },
                    })
                  }
                  description="Your model's training or test dataset"
                />
              </div>
            )}

            <div className="mt-8 flex justify-end">
              {step === 1 ? (
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  disabled={!formData.name || !formData.framework || !formData.modelType}
                  className="flex items-center space-x-2 px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <span>Next</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              ) : (
                <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:hover:bg-gray-600"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={!Object.values(formData.files).every(Boolean)}
                    className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Deploy Model
                  </button>
                </div>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}