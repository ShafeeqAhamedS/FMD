import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useProjectStore } from '../store/projects';
import { ArrowLeft, ExternalLink } from 'lucide-react';

export default function ProjectPreview() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { projects } = useProjectStore();
  const project = projects.find(p => p.id === id);

  if (!project) {
    return <div>Project not found</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/dashboard')}
            className="p-2 rounded-md text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              {project.name}
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {project.description}
            </p>
          </div>
        </div>
        {project.deployedUrl && (
          <a
            href={project.deployedUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-2 px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
          >
            <span>Open in New Tab</span>
            <ExternalLink className="h-4 w-4" />
          </a>
        )}
      </div>

      <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <span className="text-gray-500 dark:text-gray-400">Status:</span>
              <span className="ml-2 font-medium text-gray-900 dark:text-white capitalize">
                {project.status}
              </span>
            </div>
            <div>
              <span className="text-gray-500 dark:text-gray-400">Framework:</span>
              <span className="ml-2 font-medium text-gray-900 dark:text-white">
                {project.framework}
              </span>
            </div>
            <div>
              <span className="text-gray-500 dark:text-gray-400">Model Type:</span>
              <span className="ml-2 font-medium text-gray-900 dark:text-white">
                {project.modelType}
              </span>
            </div>
          </div>
        </div>
        
        {project.previewUrl && (
          <div className="relative" style={{ paddingTop: '56.25%' }}>
            <iframe
              src={project.previewUrl}
              className="absolute top-0 left-0 w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        )}
      </div>
    </div>
  );
}